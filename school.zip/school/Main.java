package com.school;

//public class Main {
//    public static void main(String[] args){
//        Subject subject = new Subject("Math", "Eng", "Hindi", "SSC");
//
//        Student student = new Student("Mohit", 15, "10th Grade", subject);
//        System.out.println("Student Details:");
//        System.out.println(student);
//        Subject studentSubject = student.getSubject();
//        System.out.println("SubjectS:");
//        System.out.println(studentSubject);
//    }
//}
